<?php

namespace Mollie\Api\Resources;

class IssuerCollection extends \Mollie\Api\Resources\BaseCollection
{
    /**
     * @return string|null
     */
    public function getCollectionResourceName()
    {
        return null;
    }
}
